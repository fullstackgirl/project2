let movieList; 
let favouriteList;

function displayMovies(movies) {
    //let movies = res;
    let liNode = null;
    let textNode = '';
    let buttonNode = null;
   // console.log('movies.length '+movies.length);
    if (movies.length) {
        // iterates movies and creates <li> for each movie
        movies.forEach(movie => {
            // creates <li> node
            liNode = document.createElement("LI");
            // sets attribute 'id' to <li> node
            liNode.setAttribute('id', movie.id);
            // creates 'text' node
            // creates <span> node
            let spanNode = document.createElement("SPAN");
            liNode.appendChild(spanNode);
            let imgNode = document.createElement("img");
            imgNode.setAttribute('src', movie.posterPath);
            imgNode.setAttribute('alt', movie.title);
			imgNode.setAttribute('width', "200");
			imgNode.setAttribute('height', "200");
			imgNode.setAttribute('border',"#0000FF");
            buttonNode = document.createElement("BUTTON");
            textNode = document.createTextNode('Add to Favourite');
            buttonNode.appendChild(textNode);
            // sets attribute 'onclick' to <button> node
            buttonNode.setAttribute('onclick', "addFavourite(" + movie.id + ")");
            liNode.appendChild(imgNode);
            liNode.appendChild(buttonNode);
            document.getElementById('moviesList').appendChild(liNode);
        });
    }

}

function displayFavourites(favourites) {

    let liNode = null;

    if (favourites.length) {
        // iterates movies and creates <li> for each movie
        favourites.forEach(movie => {
            // creates <li> node
            liNode = document.createElement("LI");
            // sets attribute 'id' to <li> node
            liNode.setAttribute('id', movie.id);
            // creates 'text' node
            // creates <span> node
            let spanNode = document.createElement("SPAN");
            liNode.appendChild(spanNode);
            let imgNode = document.createElement("img");
            imgNode.setAttribute('src', movie.posterPath);
            imgNode.setAttribute('alt', movie.title);
			imgNode.setAttribute('width', "200");
			imgNode.setAttribute('height', "200");
            liNode.appendChild(imgNode);
            document.getElementById('favouritesList').appendChild(liNode);
        });
    }

}

function getMovies() {
     return fetch('http://localhost:3000/movies')
     .then(response => response.json())
     .then(resp => {
            displayMovies(resp);
            movieList = resp;
         return resp;
     }).catch(err => err);
 }
 
 //Function to get favourite movies list
 function getFavourites() {
     return fetch('http://localhost:3000/favourites')
     .then(response => response.json())
     .then(resp => {
         displayFavourites(resp);
         favouriteList = resp;
         return resp;
     }).catch(err => err);
 }

  
// adding to favourite list/json
function addFavourite(id) {
    let toBeFavourite = movieList.filter(movie => movie.id == id);
    return fetch('http://localhost:3000/favourites', {
        method: "POST",
        headers: {
            "Content-Type": "application/json; charset=utf-8"
        },
        body: JSON.stringify(toBeFavourite[0]),
    })
        .then(response => {
            // if movie was added to favourites already, throw error message
            if (response.ok) {
                // parse to json and return it
                return response.json();
            }
            throw Error('Movie is already added to favourites');
            //return Promise.reject(new Error('Movie is already added to favourites'));
        })
        .then(resp => {
            // if movie gets added, add it to DOM
          //  console.log('resp array'+[resp]);
          //  console.log('resp > '+resp);
            displayFavourites([resp]);
          //displayFavourites(resp);
            favouriteList.push(resp);
            return favouriteList;
        }).catch(err => {
            // alert error message
            alert(err.message);
        });
};

module.exports = {
     getMovies,
     getFavourites,
     addFavourite
 };

 // You will get error - Uncaught ReferenceError: module is not defined
 // while running this script on browser which you shall ignore
 // as this is required for testing purposes and shall not hinder
 // it's normal execution
 
 
 
